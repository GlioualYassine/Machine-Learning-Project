# Machine Learning From Scratch by AssemblyAI

This repository contains the code developed in the Machine Learning from scratch course on YouTube by AssemblyAI. It includes the implementations of popular ML algorithms.

[Watch the course on our YouTube channel](https://www.youtube.com/watch?v=p1hGz0w_OCo&list=PLcWfeUsAys2k_xub3mHks85sBHZvg24Jd)

The code is based on the similar repository by Python Engineer (Patrick Loeber): https://github.com/python-engineer/MLfromscratch

